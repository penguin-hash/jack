/**
 * List all Action types used in the application
 */
export default {

  SET_USER: 'SET_USER',

}
