import RulesModal from './RulesModal';

export {
  RulesModal,
}
