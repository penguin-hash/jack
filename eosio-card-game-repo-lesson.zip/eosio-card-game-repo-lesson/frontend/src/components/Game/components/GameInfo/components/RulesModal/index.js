import './RulesModal.css';
import RulesModal from './RulesModal';
export default RulesModal;
