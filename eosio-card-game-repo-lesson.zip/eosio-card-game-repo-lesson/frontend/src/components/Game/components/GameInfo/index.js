import './GameInfo.css';
import GameInfo from './GameInfo';
export default GameInfo;
