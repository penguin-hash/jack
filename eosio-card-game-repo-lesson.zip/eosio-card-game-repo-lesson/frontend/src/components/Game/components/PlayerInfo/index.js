import './PlayerInfo.css';
import PlayerInfo from './PlayerInfo';
export default PlayerInfo;
