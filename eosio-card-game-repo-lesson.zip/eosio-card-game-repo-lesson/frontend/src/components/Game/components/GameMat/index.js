import './GameMat.css';
import GameMat from './GameMat';
export default GameMat;
