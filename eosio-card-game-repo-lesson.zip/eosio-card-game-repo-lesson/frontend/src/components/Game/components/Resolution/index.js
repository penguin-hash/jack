import './Resolution.css';
import Resolution from './Resolution';
export default Resolution;
