import './PlayerProfile.css';
import PlayerProfile from './PlayerProfile';
export default PlayerProfile;
