import './Card.css';
import Card from './Card';
export default Card;
