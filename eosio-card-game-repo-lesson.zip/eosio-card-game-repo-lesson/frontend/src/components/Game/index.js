import './Game.css';
import Game from './Game';
export default Game;
