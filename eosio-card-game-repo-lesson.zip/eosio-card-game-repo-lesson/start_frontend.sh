#!/usr/bin/env bash

# change to script's directory
cd "$(dirname "$0")/frontend"

echo "=== npm start ==="
npm start
